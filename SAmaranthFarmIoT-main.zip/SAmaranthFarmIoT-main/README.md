# SAmaranthFarmIoT
Welcome to my project. The name is SAmaranth Farm IoT
